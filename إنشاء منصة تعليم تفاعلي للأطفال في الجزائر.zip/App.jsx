import { useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { BookOpen, Calculator, Microscope, Star, Trophy, User, Settings, CreditCard } from 'lucide-react'
import SubscriptionPage from './components/SubscriptionPage'
import './App.css'

// Main Dashboard Component
function Dashboard() {
  const [userProgress, setUserProgress] = useState({
    reading: 75,
    math: 60,
    science: 45,
    totalXP: 1250,
    level: 8,
    streak: 5
  })

  const subjects = [
    {
      id: 'reading',
      name: 'القراءة',
      icon: BookOpen,
      progress: userProgress.reading,
      color: 'bg-blue-500',
      lessons: 12,
      completed: 9
    },
    {
      id: 'math',
      name: 'الرياضيات',
      icon: Calculator,
      progress: userProgress.math,
      color: 'bg-green-500',
      lessons: 15,
      completed: 9
    },
    {
      id: 'science',
      name: 'العلوم',
      icon: Microscope,
      progress: userProgress.science,
      color: 'bg-purple-500',
      lessons: 10,
      completed: 4
    }
  ]

  const achievements = [
    { name: 'قارئ ماهر', icon: '📚', earned: true },
    { name: 'عالم رياضيات', icon: '🔢', earned: true },
    { name: 'مستكشف العلوم', icon: '🔬', earned: false },
    { name: 'متعلم مثابر', icon: '⭐', earned: true }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4" dir="rtl">
      {/* Header */}
      <header className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
              <User className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-800">مرحباً أحمد!</h1>
              <p className="text-gray-600">المستوى {userProgress.level} • {userProgress.totalXP} نقطة</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="flex items-center gap-1">
              <Star className="w-4 h-4" />
              {userProgress.streak} أيام متتالية
            </Badge>
            <Link to="/subscription">
              <Button variant="outline" size="sm" className="flex items-center gap-2">
                <CreditCard className="w-4 h-4" />
                الاشتراكات
              </Button>
            </Link>
            <Button variant="outline" size="sm">
              <Settings className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Subjects Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {subjects.map((subject) => {
              const Icon = subject.icon
              return (
                <Card key={subject.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className={`w-10 h-10 ${subject.color} rounded-lg flex items-center justify-center`}>
                        <Icon className="w-5 h-5 text-white" />
                      </div>
                      <Badge variant="outline">{subject.completed}/{subject.lessons}</Badge>
                    </div>
                    <CardTitle className="text-lg">{subject.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>التقدم</span>
                        <span>{subject.progress}%</span>
                      </div>
                      <Progress value={subject.progress} className="h-2" />
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Recent Lessons */}
          <Card>
            <CardHeader>
              <CardTitle>الدروس الأخيرة</CardTitle>
              <CardDescription>تابع تعلمك من حيث توقفت</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { title: 'الحروف الهجائية - الجزء الثالث', subject: 'القراءة', progress: 80, color: 'bg-blue-500' },
                  { title: 'الجمع والطرح - التمارين التطبيقية', subject: 'الرياضيات', progress: 60, color: 'bg-green-500' },
                  { title: 'دورة الماء في الطبيعة', subject: 'العلوم', progress: 30, color: 'bg-purple-500' }
                ].map((lesson, index) => (
                  <div key={index} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                    <div className={`w-3 h-3 ${lesson.color} rounded-full`}></div>
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-800">{lesson.title}</h4>
                      <p className="text-sm text-gray-600">{lesson.subject}</p>
                    </div>
                    <div className="text-left">
                      <p className="text-sm font-medium">{lesson.progress}%</p>
                      <Progress value={lesson.progress} className="w-20 h-1" />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Avatar */}
          <Card>
            <CardHeader>
              <CardTitle>شخصيتك الافتراضية</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <div className="w-24 h-24 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                <span className="text-3xl">👦</span>
              </div>
              <h3 className="font-bold text-gray-800">أحمد المتعلم</h3>
              <p className="text-sm text-gray-600">المستوى {userProgress.level}</p>
              <Button className="mt-3" variant="outline" size="sm">
                تخصيص الشخصية
              </Button>
            </CardContent>
          </Card>

          {/* Achievements */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="w-5 h-5" />
                الإنجازات
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                {achievements.map((achievement, index) => (
                  <div
                    key={index}
                    className={`p-3 rounded-lg text-center ${
                      achievement.earned ? 'bg-yellow-50 border border-yellow-200' : 'bg-gray-50 border border-gray-200'
                    }`}
                  >
                    <div className="text-2xl mb-1">{achievement.icon}</div>
                    <p className={`text-xs font-medium ${
                      achievement.earned ? 'text-yellow-800' : 'text-gray-500'
                    }`}>
                      {achievement.name}
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Daily Challenge */}
          <Card>
            <CardHeader>
              <CardTitle>التحدي اليومي</CardTitle>
              <CardDescription>أكمل 3 دروس اليوم</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Progress value={66} className="h-2" />
                <p className="text-sm text-gray-600">2 من 3 دروس مكتملة</p>
                <Button className="w-full" size="sm">
                  ابدأ الدرس التالي
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/subscription" element={<SubscriptionPage />} />
      </Routes>
    </Router>
  )
}

export default App
