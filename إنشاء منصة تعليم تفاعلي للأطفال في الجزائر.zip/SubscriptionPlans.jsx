import React, { useState, useEffect } from 'react';
import './SubscriptionPlans.css';

const SubscriptionPlans = ({ userRole = 'student', onSelectPlan }) => {
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedBilling, setSelectedBilling] = useState('monthly');
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchPlans();
  }, [userRole]);

  const fetchPlans = async () => {
    try {
      setLoading(true);
      const response = await fetch(`http://localhost:5000/api/subscription/plans?role=${userRole}`);
      const data = await response.json();
      
      if (data.success) {
        setPlans(data.plans);
      } else {
        setError('فشل في تحميل خطط الاشتراك');
      }
    } catch (err) {
      setError('خطأ في الاتصال بالخادم');
    } finally {
      setLoading(false);
    }
  };

  const getPrice = (plan) => {
    switch (selectedBilling) {
      case 'quarterly':
        return plan.price_quarterly || plan.price_monthly * 3;
      case 'yearly':
        return plan.price_yearly || plan.price_monthly * 12;
      default:
        return plan.price_monthly;
    }
  };

  const getDiscount = (plan) => {
    const monthlyTotal = plan.price_monthly * (selectedBilling === 'quarterly' ? 3 : selectedBilling === 'yearly' ? 12 : 1);
    const actualPrice = getPrice(plan);
    if (monthlyTotal > actualPrice && actualPrice > 0) {
      return Math.round(((monthlyTotal - actualPrice) / monthlyTotal) * 100);
    }
    return 0;
  };

  const getRoleTitle = (role) => {
    const titles = {
      student: 'خطط الطلاب والأولياء',
      developer: 'خطط المطورين',
      teacher: 'خطط المعلمين',
      content_creator: 'خطط صانعي المحتوى',
      marketer: 'خطط المسوقين',
      investor: 'خطط المستثمرين',
      early_customer: 'خطط العملاء الأوائل'
    };
    return titles[role] || 'خطط الاشتراك';
  };

  const getFeaturesList = (features) => {
    const featureLabels = {
      max_students: 'عدد الطلاب',
      max_classes: 'عدد الفصول',
      max_content_uploads: 'رفع المحتوى شهرياً',
      api_calls_per_day: 'استدعاءات API يومياً',
      storage_gb: 'مساحة التخزين (جيجابايت)',
      can_create_content: 'إنشاء المحتوى',
      can_access_analytics: 'التحليلات المتقدمة',
      can_use_api: 'الوصول لـ API',
      can_publish_commercially: 'النشر التجاري',
      has_priority_support: 'الدعم الفني المميز'
    };

    return Object.entries(features).map(([key, value]) => {
      if (value === false || value === 0) return null;
      
      const label = featureLabels[key];
      if (!label) return null;

      if (typeof value === 'boolean') {
        return value ? label : null;
      }

      return `${label}: ${value === -1 || value === 0 ? 'غير محدود' : value}`;
    }).filter(Boolean);
  };

  if (loading) {
    return (
      <div className="subscription-loading">
        <div className="loading-spinner"></div>
        <p>جاري تحميل خطط الاشتراك...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="subscription-error">
        <p>{error}</p>
        <button onClick={fetchPlans} className="retry-button">إعادة المحاولة</button>
      </div>
    );
  }

  return (
    <div className="subscription-plans">
      <div className="plans-header">
        <h2>{getRoleTitle(userRole)}</h2>
        <div className="billing-toggle">
          <button 
            className={selectedBilling === 'monthly' ? 'active' : ''}
            onClick={() => setSelectedBilling('monthly')}
          >
            شهري
          </button>
          <button 
            className={selectedBilling === 'quarterly' ? 'active' : ''}
            onClick={() => setSelectedBilling('quarterly')}
          >
            ربع سنوي
          </button>
          <button 
            className={selectedBilling === 'yearly' ? 'active' : ''}
            onClick={() => setSelectedBilling('yearly')}
          >
            سنوي
          </button>
        </div>
      </div>

      <div className="plans-grid">
        {plans.map((plan) => {
          const price = getPrice(plan);
          const discount = getDiscount(plan);
          const features = getFeaturesList(plan.features);
          const isPopular = plan.tier.includes('professional') || plan.tier.includes('premium');
          const isFree = price === 0;

          return (
            <div 
              key={plan.id} 
              className={`plan-card ${isPopular ? 'popular' : ''} ${isFree ? 'free' : ''}`}
            >
              {isPopular && <div className="popular-badge">الأكثر شعبية</div>}
              {isFree && <div className="free-badge">مجاني</div>}
              
              <div className="plan-header">
                <h3>{plan.name_ar}</h3>
                <p className="plan-description">{plan.description_ar}</p>
              </div>

              <div className="plan-pricing">
                {isFree ? (
                  <div className="price-free">مجاني</div>
                ) : (
                  <>
                    <div className="price-main">
                      <span className="currency">دج</span>
                      <span className="amount">{price.toLocaleString()}</span>
                      <span className="period">/{selectedBilling === 'monthly' ? 'شهر' : selectedBilling === 'quarterly' ? 'ربع سنة' : 'سنة'}</span>
                    </div>
                    {discount > 0 && (
                      <div className="discount-badge">
                        وفر {discount}%
                      </div>
                    )}
                  </>
                )}
              </div>

              <div className="plan-features">
                <ul>
                  {features.map((feature, index) => (
                    <li key={index}>
                      <span className="feature-icon">✓</span>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              {plan.commission_rates && (plan.commission_rates.content_commission_rate > 0 || plan.commission_rates.referral_commission_rate > 0) && (
                <div className="commission-info">
                  <h4>المكافآت والعمولات:</h4>
                  {plan.commission_rates.content_commission_rate > 0 && (
                    <p>عمولة المحتوى: {(plan.commission_rates.content_commission_rate * 100)}%</p>
                  )}
                  {plan.commission_rates.referral_commission_rate > 0 && (
                    <p>عمولة الإحالة: {(plan.commission_rates.referral_commission_rate * 100)}%</p>
                  )}
                </div>
              )}

              <button 
                className="select-plan-button"
                onClick={() => onSelectPlan && onSelectPlan(plan, selectedBilling)}
              >
                {isFree ? 'ابدأ مجاناً' : 'اختر هذه الخطة'}
              </button>
            </div>
          );
        })}
      </div>

      {plans.length === 0 && (
        <div className="no-plans">
          <p>لا توجد خطط اشتراك متاحة لهذا الدور حالياً</p>
        </div>
      )}
    </div>
  );
};

export default SubscriptionPlans;

