import React, { useState } from 'react';
import './RoleSelector.css';

const RoleSelector = ({ onRoleSelect, selectedRole = 'student' }) => {
  const roles = [
    {
      id: 'student',
      name: 'طالب / ولي أمر',
      description: 'للأطفال والعائلات الراغبة في التعلم التفاعلي',
      icon: '🎓',
      color: '#007bff'
    },
    {
      id: 'teacher',
      name: 'معلم / مؤسسة تعليمية',
      description: 'للمعلمين والمدارس لإدارة الفصول والطلاب',
      icon: '👨‍🏫',
      color: '#28a745'
    },
    {
      id: 'developer',
      name: 'مطور',
      description: 'للمطورين الراغبين في بناء تطبيقات تعليمية',
      icon: '💻',
      color: '#6f42c1'
    },
    {
      id: 'content_creator',
      name: 'صانع محتوى',
      description: 'للمبدعين الراغبين في إنتاج محتوى تعليمي',
      icon: '🎨',
      color: '#fd7e14'
    },
    {
      id: 'marketer',
      name: 'مسوق',
      description: 'للمسوقين الراغبين في الترويج للمنصة',
      icon: '📈',
      color: '#20c997'
    },
    {
      id: 'investor',
      name: 'مستثمر',
      description: 'للمستثمرين الراغبين في الاستثمار في المنصة',
      icon: '💰',
      color: '#ffc107'
    },
    {
      id: 'early_customer',
      name: 'عميل مبكر',
      description: 'للعملاء الأوائل بخصومات حصرية',
      icon: '⭐',
      color: '#e83e8c'
    }
  ];

  return (
    <div className="role-selector">
      <div className="role-selector-header">
        <h2>اختر نوع حسابك</h2>
        <p>حدد الدور الذي يناسبك لعرض خطط الاشتراك المناسبة</p>
      </div>
      
      <div className="roles-grid">
        {roles.map((role) => (
          <div
            key={role.id}
            className={`role-card ${selectedRole === role.id ? 'selected' : ''}`}
            onClick={() => onRoleSelect(role.id)}
            style={{ '--role-color': role.color }}
          >
            <div className="role-icon">{role.icon}</div>
            <h3>{role.name}</h3>
            <p>{role.description}</p>
            <div className="selection-indicator">
              {selectedRole === role.id && <span>✓</span>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RoleSelector;

