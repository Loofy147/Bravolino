import { useState } from 'react'
import RoleSelector from './RoleSelector'
import SubscriptionPlans from './SubscriptionPlans'
import './SubscriptionPage.css'

function SubscriptionPage() {
  const [selectedRole, setSelectedRole] = useState('student')
  const [showPlans, setShowPlans] = useState(false)

  const handleRoleSelect = (role) => {
    setSelectedRole(role)
    setShowPlans(true)
  }

  const handleSelectPlan = (plan, billingCycle) => {
    console.log('Selected plan:', plan, 'Billing cycle:', billingCycle)
    // Here you would typically redirect to payment or registration
    alert(`تم اختيار خطة: ${plan.name_ar} - ${billingCycle}`)
  }

  const handleBackToRoles = () => {
    setShowPlans(false)
  }

  return (
    <div className="subscription-page">
      <header className="subscription-header">
        <div className="logo-container">
          <div className="logo-placeholder">
            <span className="logo-text">برافولينو</span>
          </div>
          <h1>منصة برافولينو التعليمية</h1>
        </div>
        <p className="tagline">نظام الاشتراكات المتفرع والمتوسع</p>
      </header>

      <main className="subscription-main">
        {!showPlans ? (
          <RoleSelector 
            onRoleSelect={handleRoleSelect}
            selectedRole={selectedRole}
          />
        ) : (
          <div className="subscription-section">
            <button 
              className="back-button"
              onClick={handleBackToRoles}
            >
              ← العودة لاختيار الدور
            </button>
            <SubscriptionPlans 
              userRole={selectedRole}
              onSelectPlan={handleSelectPlan}
            />
          </div>
        )}
      </main>

      <footer className="subscription-footer">
        <div className="footer-content">
          <div className="footer-section">
            <h3>برافولينو</h3>
            <p>منصة التعليم التفاعلي الرائدة للأطفال في الجزائر</p>
          </div>
          <div className="footer-section">
            <h4>الخدمات</h4>
            <ul>
              <li>محتوى تعليمي تفاعلي</li>
              <li>ألعاب تعليمية</li>
              <li>تقارير التقدم</li>
              <li>دعم فني متميز</li>
            </ul>
          </div>
          <div className="footer-section">
            <h4>للشركاء</h4>
            <ul>
              <li>برنامج المطورين</li>
              <li>شراكة المحتوى</li>
              <li>برنامج الإحالات</li>
              <li>فرص الاستثمار</li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">
          <p>&copy; 2025 برافولينو. جميع الحقوق محفوظة.</p>
        </div>
      </footer>
    </div>
  )
}

export default SubscriptionPage

